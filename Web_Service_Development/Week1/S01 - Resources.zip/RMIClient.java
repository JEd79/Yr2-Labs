import java.rmi.Naming;
import java.rmi.Remote;

public class RMIClient {
    public static void main(String[] args) {
        int port = 2021;
        try {
            // Define the client-side stub, serving as a local representation
            // of the remote object we're invoking.
            HelloRMI stub = (HelloRMI) Naming.lookup("rmi://127.0.0.1:"+port+"/Hello");

            // Call the remote object as if it were here locally§
            System.out.println("Server stub says: " + stub.Hello() + " by default");
            System.out.println("Server stub says: " + stub.Hello(HelloRMI.LANG.WELSH) + " for English");
            System.out.println("Server stub says: " + stub.Hello(HelloRMI.LANG.HUNGARIAN) + " for Hungarian");
            System.out.println("Server stub says: " + stub.Hello(HelloRMI.LANG.UNSUPPORTED) + " for unsupported language");
        } catch(Exception e) {
            e.printStackTrace(System.out);
        }
    }
}

