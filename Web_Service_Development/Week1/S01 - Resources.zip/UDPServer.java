import java.io.IOException;
import java.net.*;
public class UDPServer {

    public static void main(String[] args) {
            final int PORT_NUM = 3535;
            final int PACKET_SIZE = 256;

            try {
                // Create socket to listen for client request
                DatagramSocket socket = new DatagramSocket(PORT_NUM);
                System.out.println("Server is listening on port: "+ PORT_NUM);

                // Create a byte buffer to populate with client-sent data
                byte[] buffer = new byte[PACKET_SIZE];
                // Wrap that byte buffer with a DatagramPacket, so the low-level processing
                // is managed for us when data arrives over the socket
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

                // Receive the client-sent data, with a nice abstraction that populates the packet
                // This is a 'blocking' method, meaning the thread will stop here until data is received
                socket.receive(packet);

                // Unpack the data, assuming it's a string, and print it to standard output
                String inLine = new String(packet.getData()).trim();
                System.out.println("Client sent: "+ inLine);

                // Get the source address and port, so we know where to send our response
                // Fortunately for us, the packet object keeps track of this when data is received
                InetAddress ipAddr = packet.getAddress();
                int clientPort = packet.getPort();

                // Construct a response (as Bytes) and populate a new packet.
                // Now we have to specify the destination port and IP address
                buffer = "Hello from server!".getBytes();
                packet = new DatagramPacket(buffer, buffer.length, ipAddr, clientPort);

                // Verify the message looks as we expect, and send it over the socket
                System.out.println("Sending back: " + new String(buffer).trim());
                socket.send(packet);


            } catch (IOException e ) {
                System.out.println(e.getMessage());
            }

    }
}
