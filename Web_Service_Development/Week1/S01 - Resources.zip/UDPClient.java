import java.io.IOException;
import java.net.*;
import java.nio.charset.Charset;

public class UDPClient {
    public static void main(String[] args) {

        // Declare the socket, but don't instantiate it.
        // this is mostly optional, but won't be for packets
        DatagramSocket socket;
        final int PACKET_SIZE = 256;
        final int PORT_NUM = 3535;

        try {
            // Instantiate and initialise the socket
            socket = new DatagramSocket();

            // Allocate some room for the packet contents
            byte[] buffer = new byte[PACKET_SIZE];
            buffer = "Message!".getBytes();

            InetAddress ipAddr = InetAddress.getByName("127.0.0.1");
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length, ipAddr, PORT_NUM);

            System.out.println("Sending '" + new String(buffer, Charset.defaultCharset()) + "' to server...");
            socket.send(packet);

            buffer = new byte[PACKET_SIZE];
            packet = new DatagramPacket(buffer, buffer.length);
            socket.receive(packet);

            String inLine = new String(packet.getData()).trim();
            System.out.println("Server responded with " + inLine);

            socket.close();

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        
    }    
}
