import java.io.*;
import java.net.*;

public class TCPClient {

    public static void main(String[] args) {

        int portNum = 3939;
        try {
            InetAddress hostname = InetAddress.getByName("127.0.0.1");
            Socket clientSocket = new Socket("127.0.0.1", portNum);

            InputStream in = clientSocket.getInputStream();
            OutputStream out = clientSocket.getOutputStream();

            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            PrintWriter writer = new PrintWriter(out);

            String lineReceived;
            String lineSent = "Message!";
            writer.println(lineSent);
            writer.flush();

            System.out.println("Sending '" + lineSent + "' to server" );

            while((lineReceived = reader.readLine()) != null) {
                System.out.println("Server sent: " + lineReceived);
            }
            clientSocket.close();

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }



    }
}
