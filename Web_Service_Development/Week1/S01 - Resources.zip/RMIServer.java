import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

// This class implements the remote inferface, defining the method body,
// that is the behaviour, of this class when instantiated.
public class RMIServer implements HelloRMI {
    @Override
    public String Hello() {
        return "No language for you!";
    }

    @Override
    public String Hello(LANG language) throws RemoteException{
        switch(language) {
            case WELSH:
                return "Iawn!";
            case ENGLISH:
                return "Hello!";
            case HUNGARIAN:
                return "Szia!";
            case UNSUPPORTED:
                return "Nein!";
            default:
                throw new RemoteException("Invalid Argument");
        }

    }
    public static void main(String[] args) {
        int rmiPort = 2020;
        try {
            // Instantiate the class implementing our remote object
            RMIServer server = new RMIServer();

            // Create a local instance of a stub, so it can be publicly registered
            HelloRMI stub = (HelloRMI) UnicastRemoteObject.exportObject(server, rmiPort);
            Registry registry = LocateRegistry.createRegistry(2021);
            registry.bind("Hello", stub);
            System.out.println("Ready to accept service request");

        } catch (Exception e){
            e.printStackTrace(System.out);
        }


    }
}
