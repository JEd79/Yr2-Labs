import java.io.*;
import java.net.*;

public class TCPServer {
    public static void main(String[] args) {
        int portNum = 3939;

        try {
            // Setting up the server socket, listening for client requests
            ServerSocket serverSock = new ServerSocket(portNum);
            System.out.println("Waiting for request from client...");

            // Accept is a 'blocking' method, meaning this thread will
            // wait here for a client to initiate a TCP connection
            Socket clientSock = serverSock.accept();

            // Get the clients I/O streams, so they can communicate.
            InputStream in = clientSock.getInputStream();
            OutputStream out = clientSock.getOutputStream();

            // Wrap the raw byte streams in higher-level stream objects
            // This makes interpreting the data in our code a bit simpler.
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            PrintWriter writer = new PrintWriter(out);

            // Initialise some values for both logging server requests and responses
            String inputLine;
            String outputLine = "Sending the default response";

            // Read the client-sent data from our input stream
            // Remember, on the client-side, this would be its output stream
            inputLine = reader.readLine();

            // Check if there is data populating the stream
            // If so, show it here
            if(inputLine != null) {
                System.out.println("Server received: " + inputLine);
                outputLine = "Sending an acknowledgement response";
            }

            // Push our response to the client via our output stream
            // and flush the contents.
            writer.println(outputLine);
            writer.flush();

            // Stop listening as a server and close the TCP connection
            clientSock.close();
            serverSock.close();

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

    }
}
