import java.rmi.Remote;
import java.rmi.RemoteException;

// This defines the remote interface, providing a description of the methods
// and parameters one can expect to use in a remote method call.
public interface HelloRMI extends Remote {
    public enum LANG {
        WELSH, ENGLISH, HUNGARIAN, UNSUPPORTED
    };

    public String Hello() throws RemoteException;

    public String Hello(LANG language) throws RemoteException;
}
