package ArraySocket;

import java.io.IOException;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;

public class ArrayServer {

    private static String[] messages = {"first", "second", "third", "fourth", "last"};

    public static void main(String[] args) {
        try {
            // Set up the server socket and wait for the client to initiate connection
            ServerSocket sSoc = new ServerSocket(8283);
            Socket clientConnect = sSoc.accept();

            // Connect an output stream to the socket
            /*
             NOTE: There are some minor differences between the PrintWriter and PrintStream.
             */
            PrintStream outStream = new PrintStream(clientConnect.getOutputStream());
            
            // Output the strings in the array above
            for(String elem : messages) {
                outStream.println(elem);
            }
            
            // Close the socket - we can skip this for our simple examples
            sSoc.close();

        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

    }

}
