package ArraySocket;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class ArrayClient {
    public static void main(String[] args) {
        String inLine;
        try {
            //Connect to the server
            Socket sSoc = new Socket("localhost", 8283);
            BufferedReader in = new BufferedReader(new InputStreamReader(sSoc.getInputStream()));
            
            // We still want to process the 'last' string, so
            // switch the check to a do-while block
            do {
                inLine = in.readLine();
                System.out.println(inLine);
            } while (!inLine.equals("last"));
            
            sSoc.close();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        
    }
}
