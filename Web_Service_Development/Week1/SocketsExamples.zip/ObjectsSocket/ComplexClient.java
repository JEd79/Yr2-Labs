package ObjectsSocket;

import java.net.Socket;
import java.util.Scanner;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;
public class ComplexClient {

    public static void main(String[] args) {
        Socket socket = null;
        try {
            // Connect to the server running on localhost, port 9876
            socket = new Socket("localhost", 9876);
            System.out.println("Connected to the server!");

            // Note how these, programmatically, works the same as other I/O wrappers we've used
            // Create ObjectOutputStream to send complex data to the server
            ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());
            // Create ObjectInputStream to receive responses from the server
            ObjectInputStream input = new ObjectInputStream(socket.getInputStream());

            Scanner scanner = new Scanner(System.in);
            String userInput;
            while (true) {
                System.out.println("Enter the type of data to send (int, float, boolean, string, or 'exit' to quit): ");
                userInput = scanner.nextLine();

                if (userInput.equalsIgnoreCase("exit")) {
                    break;
                }
                // Note: the key difference here, to our other examples,
                // is that the Object I/O stream wrappers have methods for reading and
                // writing objects, as opposed to just bytes or other primitives.
                switch (userInput.toLowerCase()) {
                    case "int":
                        System.out.print("Enter an integer: ");
                        int intData = scanner.nextInt();
                        output.writeObject(intData);
                        break;
                    case "float":
                        System.out.print("Enter a float: ");
                        float floatData = scanner.nextFloat();
                        output.writeObject(floatData);
                        break;
                    case "boolean":
                        System.out.print("Enter a boolean (true/false): ");
                        boolean boolData = scanner.nextBoolean();
                        output.writeObject(boolData);
                        break;
                    case "string":
                        System.out.print("Enter a string: ");
                        String stringData = scanner.nextLine();
                        output.writeObject(stringData);
                        break;
                    default:
                        System.out.println("Unsupported data type. Please try again.");
                        continue;
                }
                output.flush();  // Ensure data is sent

                // Receive the server's response and print it to console
                String serverResponse = (String) input.readObject();
                System.out.println("Server response: " + serverResponse);

                // Clear the scanner's newline character if necessary
                scanner.nextLine();
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (socket != null) {
                    socket.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
