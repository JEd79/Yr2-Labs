package ObjectsSocket;

import java.net.*;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;

public class ComplexServer {
    public static void main(String[] args) {
        ServerSocket serverSocket = null;
        Socket clientSocket = null;
        try {
            // Create server socket listening on port 9876
            serverSocket = new ServerSocket(9876);
            System.out.println("Server is waiting for a connection...");

            // Accept client connection
            clientSocket = serverSocket.accept();
            System.out.println("Client connected!");

            // Note how the following I/O stream wrappers function (virtually)
            // the same as ones we've used in the past.
            // Create ObjectInputStream to receive complex data from the client
            ObjectInputStream input = new ObjectInputStream(clientSocket.getInputStream());
            // Create ObjectOutputStream to send responses to the client
            ObjectOutputStream output = new ObjectOutputStream(clientSocket.getOutputStream());

            // Read data from client and determine its type
            Object receivedData;
            while ((receivedData = input.readObject()) != null) {
                String response = "Unknown data type";
                if (receivedData instanceof Integer) {
                    response = "Received an Integer: " + receivedData;
                } else if (receivedData instanceof Float) {
                    response = "Received a Float: " + receivedData;
                } else if (receivedData instanceof Boolean) {
                    response = "Received a Boolean: " + receivedData;
                } else if (receivedData instanceof String) {
                    response = "Received a String: " + receivedData;
                }

                // Send response back to the client
                output.writeObject(response);
                output.flush();
                System.out.println("Sent response: " + response);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (clientSocket != null) clientSocket.close();
                if (serverSocket != null) serverSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
