package uk.ac.swan.adult.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;

import uk.ac.swan.adult.models.Adult;

/**
 * The AdultReaderService class is responsible for reading data from a CSV file
 * and converting each valid row into an Adult object.
 * <p>
 * It stores these Adult objects in a HashMap, where each entry is keyed
 * by a unique integer ID.
 */
public class AdultReaderService {

    // Path of the file int he resources dir
    private final static String RESOURCE_PATH = "data/adult.csv";

    // Keeps track of a unique ID assigned to each Adult object read from the file
    private static int dataID = 0;

    /**
     * Increments the dataID counter by one.
     * Used each time a new Adult record is added to the map.
     */
    public static void incDataID() {
        dataID++;
    }

    /**
     * Returns the current value of dataID.
     */
    public static int getDataID() {
        return dataID;
    }

    /**
     * Checks whether a given CSV row contains invalid data.
     * A row is considered invalid if:
     * - any field is null,
     * - any field is blank, or
     * - any field contains the placeholder "?" (used for missing data).
     *
     * @param data the values from a single CSV row
     * @return true if the row is invalid, false otherwise
     */
    private static boolean isInvalidRow(String[] data) {
        for (String value : data) {
            if (value == null || value.isBlank() || value.equals("?")) {
                return true;
            }
        }
        return false;
    }

    /**
     * Converts a single row of CSV data into an Adult object.
     * Assumes that the data array has the correct number of fields
     * and that all required numeric values can be parsed successfully.
     *
     * @param data an array of strings representing one line of CSV input
     * @return an Adult object created from the row data
     */
    private static Adult parseAdult(String[] data) {
        return new Adult(Integer.parseInt(data[0]), data[1], data[2], data[3], Double.parseDouble(data[4]), data[5], data[6], data[7],
                data[8], data[9], Double.parseDouble(data[10]), Double.parseDouble(data[11]), Double.parseDouble(data[12]), data[13],
                data[14]);
    }

    /**
     * Reads data from the CSV file and returns a HashMap of Adult objects.
     * <p>
     * The map’s key is an integer ID (assigned automatically), and
     * the value is the corresponding Adult object parsed from the file.
     * <p>
     * Invalid rows (missing or placeholder data) are skipped.
     *
     * @return a HashMap containing all valid Adult records from the CSV file
     * @throws IOException if the resource cannot be read. See {@link BufferedReader#readLine()}
     */
    public static HashMap<Integer, Adult> readAdults() throws IOException {
        HashMap<Integer, Adult> adults = new HashMap<>();
        BufferedReader br =
                new BufferedReader(new InputStreamReader(AdultReaderService.class.getClassLoader().getResourceAsStream(RESOURCE_PATH)));
        while (br.readLine() != null) {
            String[] csvRowData = br.readLine().strip().split(",");
            if (!isInvalidRow(csvRowData)) {
                adults.put(getDataID(), parseAdult(csvRowData));
                incDataID();
            }
        }
        br.close();

        return adults;
    }
}

